//muda o nome a partir do seletor de classe
var pacientes = document.querySelector(".subtitulo");
pacientes.textContent = "Meus Pacientes";
var Aparecida = document.querySelector(".titulo");
Aparecida.textContent = "Matheus nutrição";

//acessar a tag tr - paciente Paulo
var paciente = document.querySelector("#primeiro-cliente");

//seleciona o conteudo peso da tag
var tdPeso = paciente.querySelector(".info-peso");
var peso = tdPeso.textContent;

//seleciona o conteudo altura da tag
var tdAltura = paciente.querySelector(".info-altura");
var altura = tdAltura.textContent;

//calcula o imc
var imc = peso / (altura * altura);

//acessa  e altera o imc
var tdImc = paciente.querySelector(".info-imc");
tdImc.textContent = imc;

if(peso < 0 ||peso > 1000){
    alert("foi mogado");
}

if(altura < 0 ||altura > 1000){
    alert("só sobra o churrascamento");
}